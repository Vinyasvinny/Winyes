# SnookerClub-WebTemplate
This is a non-responsive web template created using frontend web developmnet, by a beginner for a snooker club. 
The home page , about page and the events page are the 3 pages created and if clicked on "Click Here" button , it redirects to events page.
